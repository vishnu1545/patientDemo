package com.example.loginDemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

	@GetMapping("/login")
	public Long login(@RequestParam String user,@RequestParam String password ) {
		
		if(user.equals("vishnu")&& password.equals("1234"))
	return 100000L;
		else
			return 0l;
	}
}
